<?php

$ville = htmlEntities($_GET["ville"],ENT_QUOTES);

?>
<!DOCTYPE html>
<html xml:lang="fr" >
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<body>
<h2><a href= "https://news.google.com/"> Google Actualités </a></h2>


<?php
	$actualites = new DOMDocument();
	if($actualites->load("http://news.google.com/news?pz=1&cf=all&ned=fr&hl=fr&geo=".$ville."&output=rss")){
		$articles= $actualites->getElementsByTagName("item");
		if(($articles->length)>= 2){
			echo "<h3> L'actualité de : ".$ville." et ses alentours</h3>";
			for($i=0;$i<10;$i++){
				$item=$articles->item($i);
				echo $item->getElementsByTagName("description")->item(0)->nodeValue;
			}	

		}else{
			$actualites = new DOMDocument();
			$ville = "paris";
			if($actualites->load("http://news.google.com/news?pz=1&cf=all&ned=fr&hl=fr&geo=".$ville."&output=rss")){
				$articles= $actualites->getElementsByTagName("item");
				if(($articles->length)>= 2){
					echo "<h3> L'actualité de : ".$ville." et ses alentours</h3>";
					for($i=0;$i<10;$i++){
						$item=$articles->item($i);
						echo $item->getElementsByTagName("description")->item(0)->nodeValue;
					}
				}else{
					echo "Pas d'actualité pour ".$ville." .";
				}
			}else{
				echo "Pas d'actualité pour ".$ville." .";
			}
		}
	}else{
		echo "Pas d'actualité pour ".$ville." .";
	
	}
	
?>

</body>
</html>