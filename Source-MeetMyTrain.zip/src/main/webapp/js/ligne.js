var params = location.search.substring(1);
var temp = params.split("=");
var ligne = temp[1];
if(ligne){
while (ligne.indexOf('+') > -1) {
	ligne = ligne.replace("+"," ");
}
while (ligne.indexOf(',') > -1) {
	ligne = ligne.replace(","," ");
}
}
var tableauGare =  document.getElementById("lesGares");

/*Affiche les stations par lesquelles une ligne passe */
function afficherStations(){
	if(ligne && ligne!=""){
	//var URLV="http://localhost:8080/SITE-SNCF/ListeStations?ligne="+ligne+"&callback=?";
	var URLV="http://peaceful-sands-6919.herokuapp.com/ListeStations?ligne="+ligne+"&callback=?";
	$.ajax({
		url : URLV,
		type : 'get',
		dataType : 'jsonp',
		success : function(res) {
			if(!res || !res[0].nomStation) tableauGare.innerHTML="<h1>Aucune station n'a été trouvée</h1>";
			else{
				var temp = '<ul class="list-group">';
				for(var i = 0; i<res.length;i++){
					var name = res[i].nomStation;
					var nameURL = res[i].nomStation;
					while (name.indexOf(',') > -1) {
						name = name.replace(","," ");
					}
					while (nameURL.indexOf(',') > -1) {
						nameURL = nameURL.replace(",","+");
					}
					temp+='<li class="list-group-item"><a href=station.jsp?name=';
					temp+=nameURL+'>';
					temp+=name;
					temp+="</a></li>";
				}
				temp+='</ul>';
				tableauGare.innerHTML=temp;
			}
		
			
		},
		error : function(e, msg) {
			alert("error");
		}
	});
	}else tableauGare.innerHTML="<h1>Aucune station n'a été trouvée</h1>";

}

document.body.onload = function(){
	afficherStations();
}