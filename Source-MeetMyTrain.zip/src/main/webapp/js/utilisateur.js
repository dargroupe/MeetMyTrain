
//Fonction appelée lors de l'affichage de la page message d'un utilisateur connectée
function initMessage()
{
	//N'affiche les messages que si l'utilisateur est connecté, et que la page de message correspond à la sienne
	if(getPseudoSession() == getPseudoUrl())
	{
		//On récupére tous les messages de l'utilisateur
		var URLV = "http://peaceful-sands-6919.herokuapp.com/ReadMessages?idRecoit="+getPseudoSession()+"&callback=?";
		$.ajax({ 
			url: URLV , 
			type: 'get', 
			dataType: 'jsonp',
			success: readDataMessage, //Et on appelle la fonction pour les afficher avec la liste en paramètre
			error: function(e , msg){ 
				//Sinon on affiche un message d'erreur 
				document.getElementById("contenuPage").innerHTML = "<h1>Erreur lors de la lecture des messages</h1>";
			}
		}); 
	}
	else
	{
		//Si la page des messages ne correspond pas à l'utilisateur -> message d'erreur
		document.getElementById("messagerie").innerHTML = "<h1>Vous ne pouvez pas voir ces messages</h1>";
	}
}
//Lit tous les messages et les affiches dans un div messageries
function readDataMessage(res)
{
	document.getElementById("messagerie").innerHTML += "<br/><a href=\"utilisateur.jsp?pseudo=" + getPseudoUrl() + "\">Retour au profil</a>"
	//on écrit tous les message dans le div area
	ecritMessage(res, res.length);
}

//Fonction qui lit toutes les informations relatives à un utilisateur dont le pseudo est dans l'url
function rechercheUtilisateur()
{
	var pseudoUrl = getPseudoUrl().toLowerCase();
	var URLV = "http://peaceful-sands-6919.herokuapp.com/ReadUser?id="+pseudoUrl+"&type=user&callback=?";
	$.ajax({ 
		url: URLV , 
		type: 'get',  /* Dont use post it JSONP doesnt support */
		dataType: 'jsonp',
		success: readUser, //Appelle de la fonction qui affiche les informations sur un utilisateur
		error: function(e , msg){ 
			//Si il y a une erreur lors du chargement
			document.getElementById("contenuPage").innerHTML = "<h1>Erreur lors de l'affichage du pseudo</h1>";
		}
	}); 
	
}

//Fonction qui récupére le pseudo de l'url
function getPseudoUrl()
{
	var pseudovaleur = location.search.substring(1).split('&');
	var pseudo = pseudovaleur[0].split('=');
	return pseudo[1];
}

//Affiche les informations sur un utilisateur, inconnu sur l'information n'existe pas
function readUser(res)
{
	if(res[0].prenom != "")
		document.getElementById("prenomUtil").innerHTML += "<span class=\"badge\">" 
			+ res[0].prenom + "</span>";
	else
		document.getElementById("prenomUtil").innerHTML += "<span class=\"badge\">Inconnu</span>";
	if(res[0].nom != "")
		document.getElementById("nomUtil").innerHTML += "<span class=\"badge\">"
			+ res[0].nom + "</span>";
	else
		document.getElementById("nomUtil").innerHTML += "<span class=\"badge\">Inconnu</span>";
	
	document.getElementById("ageUtil").innerHTML += "<span class=\"badge\">"
		+ res[0].age + "</span>";
	document.getElementById("villeUtil").innerHTML += "<span class=\"badge\">"
		+ res[0].ville + "</span>";
	document.getElementById("sexeUtil").innerHTML += "<span class=\"badge\">"
		+ res[0].sexe + "</span>";
	document.getElementById("interetUtil").innerHTML += "<span class=\"badge\">"
		+ res[0].interesse_par + "</span>";
	if(res[0].descriptif != "")
	{
		//Décode l'inscription de l'utf8
		var desc = (res[0].descriptif).split("%0A").join("<br/>");
		desc = decodeURIComponent(desc);
		document.getElementById("descrUtilContenu").innerHTML += desc.split("+").join(" ");
	}
	else
		document.getElementById("descrUtilContenu").innerHTML += "Aucun descriptif pour cet utilisateur";
}

function messagerie()
{
	var pseudoUrl = getPseudoUrl();;
	//if(pseudoSession == pseudoUrl){
	if(getPseudoSession().toLowerCase() == pseudoUrl.toLowerCase())
	{
			litMessages(pseudoUrl);
		//Si l'utilisateur est sur sa page perso ET qu'il est connecté
		//alors on affiche ses message
		//litMessages(pseudoSession);
		
	}
	else
	{
		//Sinon l'utilisateur n'est pas connecté, ou alors ce n'est pas sa propre page
		//et on affiche une text area pour qu'il puisse écrire un message
		document.getElementById("labMessagerie").innerHTML = "Envoyer un message :";
		document.getElementById("area").innerHTML +=
			"<textarea style=\"overflow:auto;resize:none\" rows=\"7\" id=\"textMessage\""
			+" placeholder=\"Entrer votre texte\"></textarea>";
		document.getElementById("area2").innerHTML +=
			"<button type=\"button\" onclick=\"envoiMessage();\">Envoyer</button><br/>"
	}
}

//initialise la page lors du chargement
function init()
{
	var pseudoSession = getPseudoSession();
	var title = document.getElementsByTagName("title");
	title[0].innerHTML += getPseudoUrl(); //On ajoute dans le titre le pseudo de l'util
	rechercheUtilisateur(); //Ensuite on affiche les informations de l'util
	messagerie(pseudoSession); //Et on initialise la messagerie
}

//Envoi un message si l'utilisateur est connecté
function envoiMessage()
{	
	var pseudoSession = getPseudoSession();
	
	//Si l'utilisateur est connecter on envoi le message
	if(pseudoSession != ""){
		var pseudoUrl = getPseudoUrl();
		var url = "http://peaceful-sands-6919.herokuapp.com/Insert";
		var data = "idEnvoi=" + pseudoSession
				+"&contenu="+encodeURIComponent(textMessage.value)
				+"&idRecoit=" + pseudoUrl
				+"&table=Messagerie";
		$.ajax({
			url: url,
			type: "POST",
			crossDomain: true,
			data: data,
			success:function(result){
				alert("Message envoye");
			},
			error:function(xhr,status,error){
				alert(status + " : " + error.message);
			}
		});
		textMessage.value="";
	}
	else //Si il n'est pas connecté, on le redirige vers la page de connexion
	{
		document.location.href="/Connexion" 
	}
}
function litMessages(pseudoSession){
	var URLV = "http://peaceful-sands-6919.herokuapp.com/ReadMessages?idRecoit="+pseudoSession.toLowerCase()+"&callback=?";
	$.ajax({ 
		url: URLV , 
		type: 'get',  /* Dont use post it JSONP doesnt support */
		dataType: 'jsonp',
		success: readData, 
		error: function(e , msg){ 
			//document.getElementById("contenuPage").innerHTML = "<h1>Cet utilisateur n'existe pas : " + pseudoSession + "</h1>";
			document.getElementById("labMessagerie").innerHTML = "<br/>Aucun message<br/>";
		}
	}); 
}
function readData(res)
{
	//On limite à 5 le nombre de message affiché
	var cpt = 0;
	if(res.length < 5)
		cpt = res.length;
	else 
		cpt = 5;
	
	//Puis on écrit les message dans le div area
	ecritMessage(res, cpt);
	
	//Si l'utilisateur à plus de message, il peux cliquer sur une page qui va lui afficher tous ses messages
	if(res.length > 5)
	{
		document.getElementById("area").innerHTML += "<br/><a href=\"message.jsp?pseudo=" + getPseudoUrl() + "\">Voir tous les messages</a>";	
	}

	
}

//Fonction qui écrit les nbAffichage premiers messages de res
function ecritMessage(res, nbAffichage){
	document.getElementById("labMessagerie").innerHTML = "Vous avez "+ res.length +" messages :";
	for	(i = 0; i < nbAffichage; i++) {
		var para = "";
		var envoyeur = "<a href=\"utilisateur.jsp?pseudo="+encodeURIComponent(res[i].idEnvoi)
			+ "\">"+res[i].idEnvoi+"</a>";
		para += "<p><b>De " + envoyeur + " le " + res[i].date + "</b></p>";
		var desc = (res[i].message).split("%0A").join("<br/>");
		desc = decodeURIComponent(desc);
		para += "<p>"+desc.split("+").join(" ")+"</p>";
		if(i != 0)
		{
			para += "<hr size=+4>";
		}
		document.getElementById("area").innerHTML = 
			para + document.getElementById("area").innerHTML;
	}
}