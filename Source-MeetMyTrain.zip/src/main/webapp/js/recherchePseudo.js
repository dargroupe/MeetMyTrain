var searchElementPseudo = document.getElementById('searchPseudo'),
resultsPseudo = document.getElementById('resultsPseudo'),
selectedResultPseudo = -1, // Permet de savoir quel résultat est sélectionné : -1 signifie "aucune sélection"
previousRequestPseudo, // On stocke notre précédente requête dans cette variable
previousValuePseudo = searchElementPseudo.value; // On fait de même avec la précédente valeur

function envoiPseudo(){
	document.location.href='http://peaceful-sands-6919.herokuapp.com/utilisateur.jsp?pseudo='+searchElementPseudo.value;
}


function getResultsPseudo(keywords) { // Effectue une requête et récupère les résultats
	var xhr = new XMLHttpRequest();
	xhr.open('GET', 'http://peaceful-sands-6919.herokuapp.com/ReadUser?type=search&id='+ encodeURIComponent(keywords));
	xhr.onreadystatechange = function() {
		 
		if (xhr.readyState == 4 && xhr.status == 200) {
			displayResultsPseudo(JSON.parse(xhr.responseText));
		}
	};

	xhr.send(null);
	return xhr;
}
function displayResultsPseudo(res) { // Affiche les résultats d'une requête
  	var response = decodeURI(res.id);
	resultsPseudo.style.display = response.length ? 'block' : 'none'; // On cache le conteneur si on n'a pas de résultats

 	if (response.length) { // On ne modifie les résultats que si on en a obtenu
		response = response.split('|');
		var responseLen = response.length;
		resultsPseudo.innerHTML = ''; // On vide les résultats
		
		for (var i = 0, div ; i < responseLen ; i++) {			   
			div = resultsPseudo.appendChild(document.createElement('div'));
			div.style.backgroundColor='white';
			div.innerHTML = response[i];
			div.onmouseover= function(){
				this.style.backgroundColor="grey";
			}
			div.onmouseout= function(){
				this.style.backgroundColor="white";
			}
			div.onclick = function() {
				chooseResultPseudo(this);
			};
		}

	}
}

function chooseResultPseudo(resultPseudo) { // Choisi un des résultats d'une requête et gère tout ce qui y est attaché
searchElementPseudo.value = previousValuePseudo = resultPseudo.innerHTML; // On change le contenu du champ de recherche et on enregistre en tant que précédente valeur
resultsPseudo.style.display = 'none'; // On cache les résultats
resultPseudo.className = ''; // On supprime l'effet de focus
selectedResultPseudo = -1; // On remet la sélection à "zéro"
searchElementPseudo.focus(); // Si le résultat a été choisi par le biais d'un clique alors le focus est perdu, donc on le réattribue

}
searchElementPseudo.onkeyup = function(e) {

	e = e || window.event; // On n'oublie pas la compatibilité pour IE
	if (searchElementPseudo.value != previousValuePseudo) { // Si le contenu du champ de recherche a changé
		previousValuePseudo = searchElementPseudo.value;
		if (previousRequestPseudo && previousRequestPseudo.readyState < 4) {
			previousRequestPseudo.abort(); // Si on a toujours une requête en cours, on l'arrête
		}
		previousRequestPseudo = getResultsPseudo(previousValuePseudo); // On stocke la nouvelle requête
		selectedResultPseudo = -1; // On remet la sélection à "zéro" à chaque caractère écrit

	}

}