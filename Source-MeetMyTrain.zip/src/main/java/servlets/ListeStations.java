package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ListeStations extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//Renvoie la liste des stations d'une ligne
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse response)
			throws ServletException, IOException {
		String ligne = req.getParameter("ligne");
		
		response.setContentType("text/javascript");
		PrintWriter out = response.getWriter();
		//Création de la requete sql
		String requete = "SELECT distinct nom FROM stations WHERE ligne =\""
				+ ligne + "\"";
		String res = read(requete);
		
		//On renvoit le résultat en JSONP
		String callBackJavaScripMethodName = req.getParameter("callback");
		String jsonPoutput = callBackJavaScripMethodName + res;
		out.println(jsonPoutput);
	}

	private String read(String requete) {
		String res = "";
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		/* Connexion � la base de donn�es */
		String url = "jdbc:mysql://db4free.net:3306/bdddar";
		String utilisateur = "dargroupe";
		String motDePasse = "coucou34";
		Connection connexion = null;

		Statement statement = null;
		ResultSet resultat = null;
		try {

			connexion = DriverManager.getConnection(url, utilisateur,
					motDePasse);
			/* Cr�ation de l'objet g�rant les requ�tes */
			statement = connexion.createStatement();
			System.out.println("connexion");
			/* Ex�cution d'une requ�te de lecture QUI DOIT RENVOYER UN singleton */
			resultat = statement.executeQuery(requete);
			res = "([";
			if (resultat.next()) {
				do {
					if (!res.equals("(["))
						res += ",";
					String station = resultat.getString("nom")
							.replace(' ', ',');

					res += "{\"nomStation\":\"" + station + "\"}";
				} while (resultat.next());

			}
			res += "]);";
		} catch (SQLException e) {
			System.out.println("Erreur lors de la connexion : <br/>"
					+ e.getMessage());
		} finally {
			System.out.println("Fermeture de l'objet ResultSet.");
			if (resultat != null) {
				try {
					resultat.close();
				} catch (SQLException ignore) {
				}
			}
			System.out.println("Fermeture de l'objet Statement.");
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException ignore) {
				}
			}
			System.out.println("Fermeture de l'objet Connection.");
			if (connexion != null) {
				try {
					connexion.close();
				} catch (SQLException ignore) {
				}
			}
		}
		// System.out.println(res);
		return res;
	}

}
