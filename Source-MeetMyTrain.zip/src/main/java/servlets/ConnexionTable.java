package servlets;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
/**
* se connecte à la base de donnée 
*/
public class ConnexionTable {
	/**
	*
	*@param identifiant : l'identifiant de l'utilisteur
	* @param nom : nom de l'utilisteur
	* @param prenom : prenom de l'utilisteur
	* @param age : age de l'utilisteur
	* @param ville : ville de l'utilisteur
	* @param sexe : sexe de l'utilisteur
	* @param interesse : interesse de l'utilisteur
	* @param descriptif : descriptif de l'utilisteur
	* @param mdp : mot de passe de l'utilisteur
	* @return vrai si l'ajout à été fait sinon false
	*/
	public static boolean AjoutUtilisateurDB(String identifiant, String nom, String prenom, int age, String ville, String sexe, String interesse, String descriptif, String mdp)  {
       
 
        /* Connexion à la base de données */
        String url = "jdbc:mysql://db4free.net:3306/bdddar";
        String utilisateur = "dargroupe";
        String motDePasse = "coucou34";
        Connection connexion = null;
 
		// requête à envoyer à la base de donnée
        String requete = "INSERT INTO Utilisateur VALUES ('"+identifiant+"','"+nom+"','"+prenom+"',"+age+",'"+ville+"','"+descriptif+"','"+mdp+"','"+sexe+"','"+interesse+"');";
        System.out.println(requete);
		//initialisation des variable nécessaire à la connexion
        Statement statement = null;
        ResultSet resultat = null;
         
        try {
        	try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
				return false;
			}
			// connexion à la basse de donnée
            connexion = DriverManager.getConnection(url, utilisateur,motDePasse);
            /* Cr�ation de l'objet g�rant les requ�tes */
            statement = connexion.createStatement();
			//exécution d'une requête d'écriture
            statement.executeUpdate(requete);
            System.out.println("connexion");
        } catch (SQLException e) {
            System.out.println("Erreur lors de la connexion : <br/>"
                    + e.getMessage());
            return false;
       //fermeture de la connexion
	   } finally {
            System.out.println("Fermeture de l'objet ResultSet.");
            if (resultat != null) {
                try {
                    resultat.close();
                } catch (SQLException ignore) {
                }
            }
            System.out.println("Fermeture de l'objet Statement.");
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException ignore) {
                }
            }
            System.out.println("Fermeture de l'objet Connection.");
            if (connexion != null) {
                try {
                    connexion.close();
                } catch (SQLException ignore) {
                }
            }
        }
        return true;
	}
	/**
	* se connecte à la base de donnée récupère l'utilisateur d'identifiant et vérifie que le mot de passe lui correspond
	* @param identifiant : identifiant soumis au formulaire de connexion
	* @param mdp : mot de passe soumi au formulaire de connexion
	*/
	public static boolean VerifUtilisateurDB(String identifiant,String mdp){
		
		/* initialisation des variables nécessaire à la connexion à la base de donnée */
        String url = "jdbc:mysql://db4free.net:3306/bdddar";
        String utilisateur = "dargroupe";
        String motDePasse = "coucou34";
        Connection connexion = null;
 
		// requête à envoyer
        String requete = "SELECT motdepasse FROM Utilisateur WHERE id = '"+identifiant+"';";
        System.out.println(requete);
		//variable de connexion
        Statement statement = null;
        ResultSet resultat = null;
         
        try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {	
			e.printStackTrace();
			return false;
		}
        try{
			//connexion à la base de donnée
        	connexion = DriverManager.getConnection(url, utilisateur,motDePasse);
        	 /* Création de l'objet gérant les requêtes */
            statement = connexion.createStatement();
            System.out.println("connexion");
        	/* Ex�cution d'une requ�te de lecture */
			resultat = statement.executeQuery(requete);
			//récupère le mot résultat de la requête : mot de passe 
			String mp="";
			if(resultat.next()){
				mp = resultat.getString("motdepasse");
				// vérifie la cohérence des deux mots de passes
				if(mp.equals(mdp)){
					return true;
				}else{
					return false;
				}
			}
           
        } catch (SQLException e) {
            System.out.println("Erreur lors de la connexion : <br/>"
                    + e.getMessage());
            return false;
		//déconnexion de la base de donnée
        } finally {
        	System.out.println("Fermeture de l'objet ResultSet.");
			if (resultat != null) {
				try {
					resultat.close();
				} catch (SQLException ignore) {
				}
			}
            System.out.println("Fermeture de l'objet Statement.");
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException ignore) {
                }
            }
            System.out.println("Fermeture de l'objet Connection.");
            if (connexion != null) {
                try {
                    connexion.close();
                } catch (SQLException ignore) {
                }
            }
        }
        return false;
	}
    
     
}


