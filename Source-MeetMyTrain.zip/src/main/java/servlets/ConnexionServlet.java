package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * Servlet qui affiche le formulaire de Connexion.jsp et gère les entrée de celui-ci
 */
public class ConnexionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConnexionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 *Affiche le formulaire de connexion
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// affichage du formulaire de connexion : Connexion.jsp
		
		this.getServletContext().getRequestDispatcher("/Connexion.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 *gère la vérification des champs renseigné dans le formulaire après soumission
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//crée l'objet qui vérifie les donnée du formulaire
		VerifInscription inscription = new VerifInscription();
		 //appel à la méthode de vérification  
		 boolean verifInsc=inscription.validationConnexion(request);
		 //si connexion validé
		 if(verifInsc){
			 //récupération de la session 
			 HttpSession session= request.getSession();
			 // si la session vient d'être créée
			 if(session.getAttribute("id")==null){
				//on l'initialise avec l'identifiant de l'utilisteur
				 session.setAttribute("id", request.getParameter("identifiant").trim());
			 }
			 //sinon on redirige l'utilisateur vers la page d'accueil du site
			 response.sendRedirect("/");
		//sinon 	 
		 }else{
			 //on récupère le résultat de la connexion enregistré dans la class verifInscription
			 String echec=inscription.getResultatInscription();
			 //on récupère les erreurs commise enregistré dans la class verifInscription
			 String erreurchamp = inscription.getErreursFormulaire("connexion");
			//on les associes à un attribue de request 
			 request.setAttribute("EchecConnexion",echec);
			 request.setAttribute("ErreurFormulaire",erreurchamp);
			 //on transmet le context et on affiche la page de connexion avec l'affichage des erreurs
			 this.getServletContext().getRequestDispatcher("/Connexion.jsp").forward(request, response);
			 
		 }
		 
		
	}
	}


