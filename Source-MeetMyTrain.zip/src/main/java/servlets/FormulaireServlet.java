package servlets;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
* Servlet qui gère le formulaire d'inscription
*/
public class FormulaireServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormulaireServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 * affichage du formulaire d'inscription en jsp. 
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// affichage de la page d'inscription
		this.getServletContext().getRequestDispatcher("/Formulaire.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 * traitement des donn�es saisies dans le formulaire 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//créationd de l'objet qui traite les donnée
		 VerifInscription inscription = new VerifInscription();
		 //appel à la méthode qui traite les donnée d'inscription
		 boolean verifInsc=inscription.validationInscription(request);
		 // si validation de l'inscription 
		 if(verifInsc){
			 //créer une session
			 HttpSession session= request.getSession();
			 //initialisé avec l'identifiant de l'utilisateur
			 session.setAttribute("id", request.getParameter("identifiant").trim());
			 //génération de la page de connexion par redirection
			 response.sendRedirect("Connexion.jsp");
		//sinon	 
		 }else{
			 //récupération de la liste d'erreurs
			 HashMap<String, String> erreurs =inscription.getErreurs();
			 //récupération du résultat de la tentative d'inscription
			 String echec=inscription.getResultatInscription();
			 //ajoute au contexte les erreurs
			 for(String key : erreurs.keySet()){
				 request.setAttribute(key,erreurs.get(key));
				 
			 }
			 request.setAttribute("EchecInscription",echec);
			//génération de la du formulaire d'inscription avec l'affichage des erreurs
			 this.getServletContext().getRequestDispatcher("/Formulaire.jsp").forward(request, response);
		 
			 }
		 
		
	}

}
