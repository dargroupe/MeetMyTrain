package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DeletePassager extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse response)
			throws ServletException, IOException {

		// Récupere les paramètres de la requete
		String numTrain = req.getParameter("numTrain");
		String idGareSncf = req.getParameter("idGareSncf");
		String pseudo = req.getParameter("idUser");
		response.setContentType("text/plain");
		PrintWriter out = response.getWriter();

		// Crée une requete SQL
		String requete = "DELETE FROM prend_train WHERE idUser='" + pseudo
				+ "' AND numTrain ='" + numTrain + "' AND idGareSncf ="
				+ idGareSncf + ";";
		Boolean res = update(requete);
		// Renvoi un resultat ok ou ko
		if (res == true)
			out.println("OK");
		else
			out.println("KO");
	}

	private Boolean update(String requete) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		/* Connexion � la base de donn�es */
		String url = "jdbc:mysql://db4free.net:3306/bdddar";
		String utilisateur = "dargroupe";
		String motDePasse = "coucou34";
		Connection connexion = null;

		Statement statement = null;
		Boolean resultat = false;
		try {

			connexion = DriverManager.getConnection(url, utilisateur,
					motDePasse);
			/* Cr�ation de l'objet g�rant les requ�tes */
			statement = connexion.createStatement();
			System.out.println("connexion");
			/* Ex�cution d'une requ�te de lecture QUI DOIT RENVOYER UN singleton */
			resultat = statement.execute(requete);

		} catch (SQLException e) {
			System.out.println("Erreur lors de la connexion : <br/>"
					+ e.getMessage());

		} finally {

		}
		System.out.println("Fermeture de l'objet Statement.");
		if (statement != null) {
			try {
				statement.close();
			} catch (SQLException ignore) {
			}
		}
		System.out.println("Fermeture de l'objet Connection.");
		if (connexion != null) {
			try {
				connexion.close();
			} catch (SQLException ignore) {
			}
		}

		// System.out.println(res);
		return resultat;
	}
}
