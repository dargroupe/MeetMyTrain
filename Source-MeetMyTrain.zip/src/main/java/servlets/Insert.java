package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Insert extends HttpServlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
		resp.addHeader( "Access-Control-Allow-Origin", "*" ); 
		resp.addHeader( "Access-Control-Allow-Methods", "POST" ); 
		resp.addHeader( "Access-Control-Max-Age", "1000" );
		PrintWriter out = resp.getWriter();
		
		String requete = "INSERT INTO ";
		String nomTable = req.getParameter("table");
		if(nomTable.equals("Messagerie"))
		{
			requete += " Messagerie ( idEnvoi, Message, Date, idRecoit) VALUES (";
			requete += " '" + req.getParameter("idEnvoi") + "',";
			requete += " '" + req.getParameter("contenu") + "',";
			requete += " NOW(),";
			requete += " '" + req.getParameter("idRecoit") + "');";
			
		}
		else if(nomTable.equals("prend_train"))
		{
			requete += "prend_train (numTrain, miss, idGareSncf, idUser) VALUES (";
			requete += " '" + req.getParameter("numTrain") + "',";
			requete += " '" + req.getParameter("miss") + "',";
			requete += " " + req.getParameter("idGareSncf") + ",";
			requete += " '" + req.getParameter("idUser") + "');";
		}
		else
		{
			//La table n'existe pas -> erreur
			out.println("(KO);");
		}
		out.println(insert(requete));
	}
	
	//ajoute dans la table choisit la requete en parametre
	@Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
		resp.addHeader( "Access-Control-Allow-Origin", "*" ); 
		resp.addHeader( "Access-Control-Allow-Methods", "POST" ); 
		resp.addHeader( "Access-Control-Max-Age", "1000" );
		PrintWriter out = resp.getWriter();
		
		String requete = "INSERT INTO ";
		String nomTable = req.getParameter("table");
		if(nomTable.equals("Messagerie"))
		{
			requete += " Messagerie ( idEnvoi, Message, Date, idRecoit) VALUES (";
			requete += " '" + req.getParameter("idEnvoi") + "',";
			requete += " '" + req.getParameter("contenu") + "',";
			requete += " NOW(),";
			requete += " '" + req.getParameter("idRecoit") + "');";
			
		}
		else if(nomTable.equals("prend_train"))
		{
			requete += "prend_train (numTrain, miss, idGareSncf, idUser) VALUES (";
			requete += " '" + req.getParameter("numTrain") + "',";
			requete += " '" + req.getParameter("miss") + "',";
			requete += " " + req.getParameter("idGareSncf") + ",";
			requete += " '" + req.getParameter("idUser") + "');";
		}
		else
		{
			//La table n'existe pas -> erreur
			out.println("(KO);");
		}
		out.println(insert(requete));
	}
	
	public static String insert(String req)
	{
		String url = "jdbc:mysql://db4free.net:3306/bdddar";
		String user = "dargroupe";
		String pass = "coucou34";
		Connection conn = null;
		Statement stmt = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, user, pass);
			stmt = conn.createStatement();
		  
			//Execute la requete sql
			stmt.executeUpdate(req);
		}catch(SQLException se){
			System.out.println(se.getMessage());
			return "(KO);";
		}catch(Exception e){
			System.out.println(e.getMessage());
			return "(KO);";
		}finally{
			try{
				if(stmt!=null)
					conn.close();
			}catch(SQLException se){
			}// do nothing
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se){
				System.out.println(se.getMessage());
				return "(KO);";
			}
			
		}
		return "OK";
	}
}
