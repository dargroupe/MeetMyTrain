package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ReadUser extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse response)
			throws ServletException, IOException {

		String pseudo = req.getParameter("id");
		response.setContentType("text/javascript");
		PrintWriter out = response.getWriter();
		String jsonPoutput = "";
		if(req.getParameter("type").equals("user")){ //Lit le descriptif d'un unique utilisateur
			String requete = "SELECT * FROM Utilisateur WHERE id=\"" + pseudo
					+ "\";";
			String res = read(requete,0);
			
			String callBackJavaScripMethodName = req.getParameter("callback");
			jsonPoutput = callBackJavaScripMethodName + res;
		}
		else if(req.getParameter("type").equals("search")) //Renvoi la liste des utilisateurs ayant dans leurs noms ..
		{
			String requete = "SELECT distinct id FROM Utilisateur WHERE id LIKE '%"+pseudo+"%' LIMIT 0, 10";
			jsonPoutput = read(requete,1);
		}
		out.println(jsonPoutput);
	}

	private String read(String requete, int type) {
		String res = "";
		System.out.println("requete " + requete);
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		/* Connexion à la base de données */
		String url = "jdbc:mysql://db4free.net:3306/bdddar";
		String utilisateur = "dargroupe";
		String motDePasse = "coucou34";
		Connection connexion = null;

		Statement statement = null;
		ResultSet resultat = null;
		try {
			connexion = DriverManager.getConnection(url, utilisateur,motDePasse);
			/* Création de l'objet gérant les requêtes */
			statement = connexion.createStatement();
			System.out.println("connexion");
			/* Exécution d'une requête de lecture QUI DOIT RENVOYER UN singleton */
			resultat = statement.executeQuery(requete);
		}
		catch (Exception e)
		{
			return "(KOO);";
		}
		try {

			if(resultat.next())
			{
				if(type == 0) //Renvoi la description d'un utilisateur
				{
					res = "([{";
					res += "\"nom\":\"" + resultat.getString("nom") + "\",";
					res += "\"prenom\":\"" + resultat.getString("prenom") + "\",";
					res += "\"ville\":\"" + resultat.getString("ville") + "\",";
					res += "\"age\":\"" + resultat.getString("age") + "\",";
					res += "\"sexe\":\"" + resultat.getString("sexe") + "\",";
					res += "\"interesse_par\":\"" + resultat.getString("interesse_par")
							+ "\",";
					try {
						res += "\"descriptif\":\""
								+ URLEncoder.encode(resultat.getString("descriptif"),
										"UTF-8") + "\",";
					} catch (UnsupportedEncodingException e) {
						System.err.println(e.getMessage());
					}
					res += "}]);";
				}
				else if(type == 1) //Renvoi la liste des utilisateurs ayant dans leurs noms ...
				{
					res="{\"id\":\"";
					do {
						
						String id = resultat.getString("id");
						
						try{
							id = URLEncoder.encode(id, "UTF-8");
						}
						catch (UnsupportedEncodingException e)
						{
							System.err.println(e.getMessage());
						}
						res += id + "|";
					} while(resultat.next());
					res +="\"}";
				}
			}
			else
			{
				return null;
			}
		} catch (SQLException e) {
			try {
			return "("+URLEncoder.encode(res,"UTF-8")+");";
			} catch (UnsupportedEncodingException ee) {
				System.err.println(ee.getMessage());
			}
		} finally {
			System.out.println("Fermeture de l'objet ResultSet.");
			if (resultat != null) {
				try {
					resultat.close();
				} catch (SQLException ignore) {
				}
			}
			System.out.println("Fermeture de l'objet Statement.");
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException ignore) {
				}
			}
			System.out.println("Fermeture de l'objet Connection.");
			if (connexion != null) {
				try {
					connexion.close();
				} catch (SQLException ignore) {
				}
			}
			
		}
		return res;
	}
}
