package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.PasswordAuthentication;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

public class APITransilien extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String nom = "tnhtn178";
		String mdp = "a8Qg92Lq";
		String numStationDepart = req.getParameter("idSncf");
		String typeHoraire = "depart";
		String numStationArrivee = req.getParameter("numArrivee");

		try {
			//Authentification a l'api transilien
			Authenticator.setDefault(new BasicAuthenticator(nom, mdp));
			String urlString = "http://api.transilien.com/gare/";
			if (typeHoraire.equals("depart"))
				urlString += numStationDepart + "/depart/";
			else
				urlString += numStationDepart + "/depart/" + numStationArrivee
						+ "/";
			URL url = new URL(urlString);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			BufferedReader brd = new BufferedReader(new InputStreamReader(
					conn.getInputStream()));

			resp.setContentType("application/javascript");
			resp.setCharacterEncoding("UTF-8");

			/*
			 * c'est ce qui permet de recup la fonction callback du 'client' ici
			 * le nom de fonction est générée dynamiquement et ressemble à un
			 * truc du genre jQuery111102923681016973054_1413731348557
			 */
			String callBackJavaScripMethodName = req.getParameter("callback");

			String l;
			String ligne = "";
			while ((l = brd.readLine()) != null) {// Là j'imagine que tu
													// récupère la réponse SNCF
													// au format xml
				ligne += l;
			}

			String reponse = ligne + "\n";// On suppose qu'ici ligne/reponse
											// correspond à un fichier XML

			// A partir de là on modifie la ligne xml vers du json grâce à la
			// lib json-java.jar
			// Le résultat se trouvera dans jsonPrettyPrintString
			int PRETTY_PRINT_INDENT_FACTOR = 4;
			String jsonPrettyPrintString = "Erreur Conversion";
			try {
				JSONObject xmlJSONObj = XML.toJSONObject(reponse);
				jsonPrettyPrintString = xmlJSONObj
						.toString(PRETTY_PRINT_INDENT_FACTOR);
				System.out.println(jsonPrettyPrintString);
			} catch (JSONException je) {
				System.out.println(je.toString());
			}

			String jsonPoutput = callBackJavaScripMethodName + "("
					+ jsonPrettyPrintString + ");";
			/****
			 * Typiquement on renvoi comme réponse un truc du genre jsonPoutput
			 * =
			 * 
			 * jQuery111102923681016973054_1413731348557({"passages": { "train":
			 * [ { "num": 148248, "term": 87393157, "date": { "content":
			 * "19/10/2014 17:22", "mode": "R" }, "miss": "VICK" }, { "num":
			 * 147639, "term": 87393009, "date": { "content":
			 * "19/10/2014 17:24", "mode": "R" }, "miss": "CIME" }, ], "gare":
			 * 87545269 }});
			 */
			resp.getWriter().print(jsonPoutput);
			brd.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	static class BasicAuthenticator extends Authenticator {
		String baName;
		String baPassword;

		private BasicAuthenticator(String baName1, String baPassword1) {
			baName = baName1;
			baPassword = baPassword1;
		}

		@Override
		public PasswordAuthentication getPasswordAuthentication() {
			System.out.println("Authenticating...");
			return new PasswordAuthentication(baName, baPassword.toCharArray());
		}
	};

}
