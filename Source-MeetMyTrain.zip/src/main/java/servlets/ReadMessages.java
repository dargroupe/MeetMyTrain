package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ReadMessages extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//Renvoi tous les messages d'un utilisateurs avec leurs envoyeurs, la date, etC...
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse response)
			throws ServletException, IOException {

		String idRecoit = req.getParameter("idRecoit");
		response.setContentType("text/javascript");
		PrintWriter out = response.getWriter();
		String requete = "SELECT * FROM Messagerie WHERE idRecoit=\"" + idRecoit + "\";";
		String res = read(requete);
		
		//On envoi le résultat en JSONP
		String callBackJavaScripMethodName = req.getParameter("callback");
	    String jsonPoutput = callBackJavaScripMethodName + res;
		out.println(jsonPoutput);
	}

	private String read(String requete) {
		String res = "";
		System.out.println("requete " + requete);
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		/* Connexion à la base de données */
		String url = "jdbc:mysql://db4free.net:3306/bdddar";
		String utilisateur = "dargroupe";
		String motDePasse = "coucou34";
		Connection connexion = null;

		Statement statement = null;
		ResultSet resultat = null;
		try {

			connexion = DriverManager.getConnection(url, utilisateur,
					motDePasse);
			/* Création de l'objet gérant les requêtes */
			statement = connexion.createStatement();
			System.out.println("connexion");
			/* Exécution d'une requête de lecture QUI DOIT RENVOYER UN singleton */
			resultat = statement.executeQuery(requete);
			if (resultat.next()) {
				res = "([";

				do {
					if (!res.equals("(["))
						res += ",";
					String idEnvoi = resultat.getString("idEnvoi");
					
					//Conversion en string de la date
					Timestamp timestamp = resultat.getTimestamp("date");
					String da = new SimpleDateFormat("MM/dd/yyyy ':' HH:mm:ss")
							.format(timestamp);
					String message = resultat.getString("message");
					try {
						message = URLEncoder.encode(message, "UTF-8");
					} catch (UnsupportedEncodingException e) {
						System.err.println(e.getMessage());
					}
					res += "{\"idEnvoi\":\"" + idEnvoi + "\", \"message\":\""
							+ message + "\", \"date\":\"" + da + "\"}";
				} while (resultat.next());
				res += "]);";
			}
		} catch (SQLException e) {
			System.out.println("Erreur lors de la connexion : <br/>"
					+ e.getMessage());
		} finally {
			System.out.println("Fermeture de l'objet ResultSet.");
			if (resultat != null) {
				try {
					resultat.close();
				} catch (SQLException ignore) {
				}
			}
			System.out.println("Fermeture de l'objet Statement.");
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException ignore) {
				}
			}
			System.out.println("Fermeture de l'objet Connection.");
			if (connexion != null) {
				try {
					connexion.close();
				} catch (SQLException ignore) {
				}
			}
		}
		// System.out.println(res);
		return res;

	}
}
