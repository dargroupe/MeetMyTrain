package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ReadStation extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/javascript");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();

		String type = request.getParameter("type");
		String idSncf = "";
		String nom = "";
		String res = "";
		String jsonPoutput = "KO"; //valeur par défaut
		
		//Renvoe le nom d'une station via son numéro
		if (type.equals("id")) {
			idSncf = request.getParameter("idsncf");

			String nomRequete = "SELECT nom FROM stations "
					+ "WHERE idsncf ="+idSncf;
			res = read(nomRequete, 0, out);
			res = res.replaceAll(" ", ",");

			String callBackJavaScripMethodName = request.getParameter("callback");
			jsonPoutput = callBackJavaScripMethodName + "({'nomStation':'" + res + "'});";

		} else if (type.equals("nom")) { //Renvoi le numéro d'une station via sonnom
			nom = request.getParameter("nom");

			String nomRequete = "SELECT idsncf FROM stations " + "WHERE nom ="
					+ nom + "";

			res = read(nomRequete, 1, out); 

			String callBackJavaScripMethodName = request
					.getParameter("callback");
			jsonPoutput = callBackJavaScripMethodName + "({'idSncf':'"
					+ res + "'});";
			out.println(jsonPoutput);
		} else if (type.equals("search")) { //Renvoi la liste des stations contenant dans leurs noms ..
			nom = request.getParameter("nom");
			String nomRequete = "SELECT distinct nom FROM stations WHERE nom LIKE '%"+nom+"%' LIMIT 0, 10";
			jsonPoutput = new String( read(nomRequete, 2, out));
		}
		out.println(jsonPoutput);
		out.close();
	}

	private String read(String requete, int type, PrintWriter out) {
		String res = "NoResult";
		System.out.println("requete " + requete);
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		/* Connexion à la base de données */
		String url = "jdbc:mysql://db4free.net:3306/bdddar";
		String utilisateur = "dargroupe";
		String motDePasse = "coucou34";
		Connection connexion = null;

		Statement statement = null;
		ResultSet resultat = null;
		try {
			connexion = DriverManager.getConnection(url, utilisateur,
					motDePasse);
			/* Création de l'objet gérant les requêtes */
			statement = connexion.createStatement();
			System.out.println("connexion");
			/* Exécution d'une requête de lecture QUI DOIT RENVOYER UN singleton */
			resultat = statement.executeQuery(requete);
 
			if (resultat.next()) {
				res = "";
				if (type == 0) //Si on renvoit le nom
					res = res + resultat.getString("nom");
				else if (type == 1) //Si on renvoi l'identifiant
					res = res + resultat.getInt("idsncf");
				else if (type == 2) //Si on renvoi la liste des stations contenant
				{
					res="{\"nom\":\"";
					do {
						
						String nom = resultat.getString("nom");
						
						try{
							nom = URLEncoder.encode(nom, "UTF-8");
						}
						catch (UnsupportedEncodingException e)
						{
							System.err.println(e.getMessage());
						}
						res +=nom + "|";
					} while(resultat.next());
					res +="\"}";
				}
			}

		} catch (SQLException e) {
			System.out.println("Erreur lors de la connexion : <br/>"
					+ e.getMessage());
		} finally {
			System.out.println("Fermeture de l'objet ResultSet.");
			if (resultat != null) {
				try {
					resultat.close();
				} catch (SQLException ignore) {
				}
			}
			System.out.println("Fermeture de l'objet Statement.");
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException ignore) {
				}
			}
			System.out.println("Fermeture de l'objet Connection.");
			if (connexion != null) {
				try {
					connexion.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return res;
	}
}
