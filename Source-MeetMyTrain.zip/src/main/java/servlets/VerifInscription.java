package servlets;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
/**
*vérifie les saisies dans les formulaire
*/
public final class VerifInscription {
	
	private static final String CHAMP_IDENTIFIANT = "identifiant";
	private static final String CHAMP_NOM = "nom";
	private static final String CHAMP_PRENOM = "prenom";
	private static final String CHAMP_AGE = "age";
	private static final String CHAMP_SEXE = "sexe";
	private static final String CHAMP_INTERESSE = "interesse";
	private static final String CHAMP_VILLE = "ville";
	private static final String CHAMP_DESCRIPTIF = "descriptif";
	private static final String CHAMP_MDP = "motdepasse";
	private static final String CHAMP_CONF = "confirmation";
	
	//liste des erreurs
	private HashMap<String, String> erreursFormulaire = new HashMap<String, String>();
	//résultat de la soumission
	private String resultatInscription;

	public VerifInscription() {
	}
	/**
	*@param str : valeur du champ 
	*@return l'erreur 
	*/
	public String getErreursFormulaire(String str) {
		return erreursFormulaire.get(str);
	}
	/**
	* @return la liste d'erreurs
	*/
	public HashMap<String, String> getErreurs() {
	    return erreursFormulaire;
	}
	/**
	*@return le résultat de la soumission
	*/
	public String getResultatInscription() {
		return resultatInscription;
	}

	/**
	*@request : la requête contenant la valeur de la saisie pour chaque champ
	*@return : vrai si l'inscription est valide, faux sinon
	*/
	public boolean validationInscription(HttpServletRequest request) {
		//récupération de la valeur des champs saisis
		String identifiant = request.getParameter(CHAMP_IDENTIFIANT);
		String nom = request.getParameter(CHAMP_NOM);
		String prenom = request.getParameter(CHAMP_PRENOM);
		String ageParam = request.getParameter(CHAMP_AGE);
		String sexe = request.getParameter(CHAMP_SEXE);

		String interesse = request.getParameter(CHAMP_INTERESSE);
		String ville = request.getParameter(CHAMP_VILLE);
		String descriptif = request.getParameter(CHAMP_DESCRIPTIF);
		String mdp = request.getParameter(CHAMP_MDP);
		String confirmation = request.getParameter(CHAMP_CONF);
		//vérification de la conformité des valeurs saisies 
		int age = 0;
		if (identifiant == null || identifiant.trim().length() < 6) {
			erreursFormulaire.put(CHAMP_IDENTIFIANT,
					"L'identifiant n'est pas valide");
		} else {
			identifiant = identifiant.trim();
		}
		if (nom != null) {
			nom = nom.trim();
		} else {
			nom = "";
		}
		if (prenom != null) {
			prenom = prenom.trim();
		} else {
			prenom = "";
		}
		if (ageParam == null || ageParam.trim().length() < 2
				|| ageParam.trim().length() > 2) {
			erreursFormulaire.put(CHAMP_AGE, "Votre age n'est pas valide");
		} else {
			age = Integer.parseInt(ageParam.trim());
		}
		if (sexe != null
				&& (sexe.trim().equals("Homme") || sexe.trim().equals("Femme") || sexe
						.trim().equals("Autre"))) {
			sexe = sexe.trim();
		} else {
			erreursFormulaire.put(CHAMP_SEXE, "Le champ sexe n'est pas valide");
		}
		if (interesse != null
				&& (interesse.trim().equals("Homme")
						|| interesse.trim().equals("Femme") || interesse.trim()
						.equals("Autre"))) {
			interesse = interesse.trim();
		} else {
			erreursFormulaire.put(CHAMP_INTERESSE,
					"Votre intérêt n'est pas valide");
		}
		if (descriptif != null) {
		} else {
			descriptif = "";
		}

		if (mdp != null && confirmation != null) {
			if (mdp.length() >= 6) {
				if (mdp.equals(confirmation)) {
					mdp = encode(mdp);
				} else {
					erreursFormulaire.put(CHAMP_CONF,
							"Les mots de passe sont différents ");
				}
			} else {
				erreursFormulaire.put(CHAMP_MDP,
						"Le mot de passe doit contenir au moins 6 caractères");
			}
		} else {
			erreursFormulaire.put(CHAMP_MDP, "Veuillez saisir un mot de passe");
		}
		// si pas d'érreurs
		if (erreursFormulaire.isEmpty()) {
			//appel à la méthode qui se connecte à la base de donnée
			boolean res = ConnexionTable.AjoutUtilisateurDB(identifiant, nom,
					prenom, age, ville, sexe, interesse, descriptif, mdp);
			//vérification du résultat de l'appel à la base de donnée
			if (res) {
				resultatInscription = "Inscription avec succès";
				return true;
			} else {
				resultatInscription = "L'inscription a échoué";
				System.out
						.println("echec de l'inscription au niveau de l'ajout de l'utilisateur");
				return false;
			}
		} else {
			resultatInscription = "L'inscription a échoué";
			return false;
		}
	}
	/**
	*@param request : contient la valeur des champs saisis
	*@return vrai si la connexion est valide faux sinon
	*/
	public boolean validationConnexion(HttpServletRequest request) {
		//récupération de la valeur des champs saisis
		String identifiant = request.getParameter(CHAMP_IDENTIFIANT);
		String mdp = request.getParameter(CHAMP_MDP);
		// vérification de la conformité des valeurs saisies
		if (identifiant == null || mdp == null || identifiant.trim().equals("")) {
			erreursFormulaire.put("connexion",
					"L'identifiant et/ou le mot de passe sont invalides");
			resultatInscription = "La connexion a échoué";
			return false;
		}
		// encodage du mot de passe
		mdp = encode(mdp);
		//appel à la méthode qui se connecte à la base de donnée
		boolean res = ConnexionTable.VerifUtilisateurDB(identifiant, mdp);
		//vérification du résultat de l'appel à la base de donnée
		if (res) {
			resultatInscription = "Connexion avec succès";
			return true;
		} else {
			resultatInscription = "La connexion a échoué";

			return false;
		}
	}
	/**
	*@param input : string à encoder
	@return input encoder
	*/
	private String encode(String input) {
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] messageDigest = md.digest(input.getBytes());
			BigInteger number = new BigInteger(1, messageDigest);
			String hashtext = number.toString(16);
			// Now we need to zero pad it if you actually want the full 32
			// chars.
			while (hashtext.length() < 32) {
				hashtext = "0" + hashtext;
			}
			return hashtext;
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
	}

}
