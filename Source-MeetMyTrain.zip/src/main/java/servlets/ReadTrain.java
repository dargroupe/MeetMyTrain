package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ReadTrain extends HttpServlet {

	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse response)
			throws ServletException, IOException {

		String numTrain = req.getParameter("numTrain");
		String idGareSncf = req.getParameter("idGareSncf");
		response.setContentType("text/javascript");
		PrintWriter out = response.getWriter();
		// Créatin de la requete qui selectionne les utilisateurs prenant le
		// même train dans la même gare
		String requete = "SELECT distinct idUser FROM prend_train WHERE numTrain ='"
				+ numTrain + "' AND idGareSncf =" + idGareSncf + ";";
		String res = read(requete);

		// Renvoi le résultat en jsonp
		String callBackJavaScripMethodName = req.getParameter("callback");
		String jsonPoutput = callBackJavaScripMethodName + res;
		out.println(jsonPoutput);
	}

	private String read(String requete) {
		System.out.println("Dans ReadTrain read ");
		String res = "";
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		/* Connexion A la base de donnees */
		String url = "jdbc:mysql://db4free.net:3306/bdddar";
		String utilisateur = "dargroupe";
		String motDePasse = "coucou34";
		Connection connexion = null;

		Statement statement = null;
		ResultSet resultat = null;
		try {

			connexion = DriverManager.getConnection(url, utilisateur,
					motDePasse);
			/* Cr�ation de l'objet gerant les requ�tes */
			statement = connexion.createStatement();
			System.out.println("connexion");
			/* Ex�cution d'une requ�te de lecture QUI DOIT RENVOYER UN singleton */
			resultat = statement.executeQuery(requete);
			res = "([";
			if (resultat.next()) {

				do {
					if (!res.equals("(["))
						res += ",";
					String idUser = resultat.getString("idUser");

					res += "{\"idUser\":\"" + idUser + "\"}";
				} while (resultat.next());

			}
			res += "])";
		} catch (SQLException e) {
			System.out.println("Erreur lors de la connexion : <br/>"
					+ e.getMessage());
		} finally {
			System.out.println("Fermeture de l'objet ResultSet.");
			if (resultat != null) {
				try {
					resultat.close();
				} catch (SQLException ignore) {
				}
			}
			System.out.println("Fermeture de l'objet Statement.");
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException ignore) {
				}
			}
			System.out.println("Fermeture de l'objet Connection.");
			if (connexion != null) {
				try {
					connexion.close();
				} catch (SQLException ignore) {
				}
			}
		}
		// System.out.println(res);
		return res;
	}
}
